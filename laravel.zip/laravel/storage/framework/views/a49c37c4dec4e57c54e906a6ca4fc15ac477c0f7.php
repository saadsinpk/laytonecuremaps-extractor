
<?php $__env->startSection('mainContent'); ?>
<div class="container">
    <div class="card">
        <div class="card-header"><h3 class="card-title">Add New Admins</h3></div>
        <div class="card-body">
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="d-block text-danger"><?php echo e($error); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <br>
            <?php endif; ?>
            <form action="<?php echo e(route('storeUser')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="email" class="form-label">Email</label>
                    <input type="text" class="form-control" id='email' name='email'>
                </div>
                <div class="form-group">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" id='username' name='username'>
                </div>
                <div class="form-group">
                    <label for="password" class="form-label">Password</label>
                    <input class="rounded-md shadow-sm border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 form-control form-control-lg form-control-solid" id="password" type="password" name="password" required="required" autocomplete="current-password">
                </div>
                <div class="form-group">
                    <label for="password_confirmation" class="form-label">Confirm Password</label>
                    <input class="rounded-md shadow-sm border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 form-control form-control-lg form-control-solid" id="password_confirmation" type="password" name="password_confirmation" required="required" autocomplete="current-password">
                </div>
                <br>
                <button class="btn btn-primary" type="submit">Add New</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pro_1\laravel\resources\views/pages/admins/adddata.blade.php ENDPATH**/ ?>