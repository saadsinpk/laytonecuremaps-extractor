<?php $__env->startSection('mainContent'); ?>

    <div class="d-md-none">
        <div class="menu menu-column menu-fit menu-rounded menu-title-gray-600 menu-icon-gray-400 menu-state-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-500 fw-bold fs-5 px-6 my-5 my-lg-0" id="kt_aside_menu" data-kt-menu="true">
        <div id="kt_aside_menu_wrapper" class="menu-fit">
            <div class="menu-item menu-accordion <?php echo e(Route::is('allMakeData') ? 'show' : ''); ?>">
                <a class="menu-link <?php echo e(Route::is('allMakeData') ? 'active' : ''); ?>" href="<?php echo e(route('allMakeData')); ?>">
                    <span class="menu-bullet">
                        <span class="bullet bullet-dot"></span>
                    </span>
                    <span class="menu-title">Make</span>
                </a>
            </div>
            <div class="menu-item menu-accordion <?php echo e(Route::is('allModalData') ? 'show' : ''); ?>">
                <a class="menu-link <?php echo e(Route::is('allModalData') ? 'active' : ''); ?>" href="<?php echo e(route('allModalData')); ?>">
                    <span class="menu-bullet">
                        <span class="bullet bullet-dot"></span>
                    </span>
                    <span class="menu-title">Model</span>
                </a>
            </div>
            <div class="menu-item menu-accordion <?php echo e(Route::is('allGenData') ? 'show' : ''); ?>">
                <a class="menu-link <?php echo e(Route::is('allGenData') ? 'active' : ''); ?>" href="<?php echo e(route('allGenData')); ?>">
                    <span class="menu-bullet">
                        <span class="bullet bullet-dot"></span>
                    </span>
                    <span class="menu-title">Generation</span>
                </a>
            </div>
            <div class="menu-item menu-accordion <?php echo e(Route::is('allEngineData') ? 'show' : ''); ?>">
                <a class="menu-link <?php echo e(Route::is('allEngineData') ? 'active' : ''); ?>" href="<?php echo e(route('allEngineData')); ?>">
                    <span class="menu-bullet">
                        <span class="bullet bullet-dot"></span>
                    </span>
                    <span class="menu-title">Engine</span>
                </a>
            </div>
            <div class="menu-item menu-accordion <?php echo e(Route::is('allDataData') ? 'show' : ''); ?>">
                <a class="menu-link <?php echo e(Route::is('allDataData') ? 'active' : ''); ?>" href="<?php echo e(route('allDataData')); ?>">
                    <span class="menu-bullet">
                        <span class="bullet bullet-dot"></span>
                    </span>
                    <span class="menu-title">Data</span>
                </a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pro_1\laravel\resources\views/index.blade.php ENDPATH**/ ?>